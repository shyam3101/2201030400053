# Online Book Store - Full PHP & MYSQL Project

version: 1.0.0

### Admin User Name : eliasfsdev@gmail.com

### Admin Password : 12345

## Full Tutorial

[On Youtube](https://youtube.com/playlist?list=PL2WFgdVk-usF5q_zBoHCFeGEj7NCQ_YLq)

## DEMO

[DEMO](https://youtu.be/IMCHi-5Ig40)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)